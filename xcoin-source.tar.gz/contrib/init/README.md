Sample configuration files for:
```
SystemD: xcoind.service
Upstart: xcoind.conf
OpenRC:  xcoind.openrc
         xcoind.openrcconf
CentOS:  xcoind.init
macOS:    org.xcoin.xcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
